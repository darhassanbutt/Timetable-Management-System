public class Runner {
    static String[] faculty = {
        "Dr. Alam Zaib", "Dr.Faisal Mehmood", "Dr.Imdad Khan", "Ayaz Ali Shah", "Zulfiqar Khattak"
    };
    static String header[] = {"Days", "8:00 - 9:30", "9:40 - 11:10", "11:20 - 12:50",
                            "13:20 - 15:10","15:20 - 16:50","17:00 - 18:30"};
    static TimeTableGenerator table = generateAndAssign();
    static String[] sections = table.sections;
    
    public static void generate(){
        table = generateAndAssign();
    }

    public static TimeTableGenerator generateAndAssign(){
        TimeTableGenerator object = new TimeTableGenerator("BCE-4", faculty, 5, 3);
        int a = 10;
        for(int i = 1; i <= a; i++){
            try{
                object.assign();
                System.out.println("Time Tables created succesfully.");      
                break;
            }
            catch(IllegalArgumentException e){
                System.out.println(e.getMessage());
                if(i < a)
                    System.out.printf("Trying again: %d/%d\n", i, a);
                else
                    System.out.println("Maybe reconsider the values.");
                object = new TimeTableGenerator("BCE-4", faculty, 5, 3);
            }
        }
        return object;
    }
}
