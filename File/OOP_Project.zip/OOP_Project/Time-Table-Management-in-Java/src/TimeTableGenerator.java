import java.security.SecureRandom;
import java.util.Arrays;

public class TimeTableGenerator{
    String departmentPlusYear;
    String[] faculty;
    String[][][] classes;
    String[] sections;
    int[][] recordIndexI, recordIndexJ;
    int totalClasses, lecturesPerWeek, totalLecturesPerTeacher, index;

    public TimeTableGenerator(String departmentPlusYear, String[] faculty, int totalClasses, int lecturesPerWeek){
        this.departmentPlusYear = departmentPlusYear;
        this.faculty = faculty;
        this.totalClasses = totalClasses;
        this.lecturesPerWeek = lecturesPerWeek;
        totalLecturesPerTeacher = totalClasses*lecturesPerWeek;
        recordInitialzer();
    }

    private void recordInitialzer(){
        classes = new String[totalClasses][6][6];
        sections = new String[totalClasses];
        for(int i = 0; i < totalClasses; i++){
            sections[i] = departmentPlusYear + (char)('A'+i);
        }
        recordIndexI = new int[faculty.length][totalLecturesPerTeacher];
        recordIndexJ = new int[faculty.length][totalLecturesPerTeacher];
        for(int i = 0; i < recordIndexI.length; i++){
            Arrays.fill(recordIndexI[i], -1);
            Arrays.fill(recordIndexJ[i], -1);
        }
    }

    public void assign(){
        for(int i = 0; i < faculty.length; i++){
            for(int j = 0; j < classes.length; j++){
                assignHelperMethod(faculty[i], i, classes[j]);
            }
        }
    }

    public String[][] get2Darray(int index){
        return classes[index];
    }
    public String[][][] get3Darray(){
        return classes;
    }

    private void assignHelperMethod(String teacher, int teacherIndex, String[][] table){
        int filled = 0, attempts = 0;
        SecureRandom r = new SecureRandom();
        if(index == totalLecturesPerTeacher){
            index = 0;
        }
        while(filled < lecturesPerWeek){
            int i = r.nextInt(5), j = r.nextInt(6);
            attempts++;
            boolean valid = validityVerifier(i, j, teacher, teacherIndex, table);
            if(table[i][j] == null && valid){
                table[i][j] = teacher;
                recordIndexI[teacherIndex][index] = i;
                recordIndexJ[teacherIndex][index] = j;
                index++;
                filled++;
            }
            if(attempts == 10000000){
                throw new IllegalArgumentException("Time Tables cannot be created as clash cannot be resolved.");
            }      
        }
    }

    private boolean validityVerifier(int row, int col, String teacher, int teacherIndex, String[][] table){
        // checking for an already existing i,j pair for a given teacher
        for(int i = 0; i < recordIndexI[0].length; i++){
            if(recordIndexI[teacherIndex][i] == row && recordIndexJ[teacherIndex][i] == col)
                return false;
        }
        // check the entire row of the table
        for(int i = 0; i < table[0].length; i++){
            if(teacher.equals(table[row][i])){
                return false;
            }
        }
        // check entire columnn of the table
        for (int i = 0; i < table.length; i++) {
            if (teacher.equals(table[i][col])) {
                return false;
            }
        }
        return true;
    }

    public String[][] getteacher2Darray(int teacherIndex){
        String array[][] = new String[6][6];
        int inc = 0, count = 0;
        for(int i = 0; i < recordIndexI[0].length; i++){
            array[recordIndexI[teacherIndex][i]][recordIndexJ[teacherIndex][i]] = sections[inc];
            count++;
            if(count == lecturesPerWeek){
                inc++;
                count = 0;
            }
        }
        return array;
    }
}